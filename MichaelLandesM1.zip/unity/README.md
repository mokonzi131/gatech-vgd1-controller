gatech-vgd1-controller
======================

Sphere Controller in Unity

Sources of Help
Wikipedia and Google for common physics equations especially concerning rotation geometry and quaternions.
Unity's website for some of the API calls

Install Instructions
Open Unity project, and open "ControllerScene.unity" which should be the only scene present.
The Assets folder contains everything I added to the project, including "PlayerController.cs" and "ChaseCamera.cs"
